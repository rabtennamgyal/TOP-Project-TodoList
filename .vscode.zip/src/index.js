// Sass files 🔮
import'./sass/main.scss'


// JavaScript
import Paintdom from './Modules/Paintdom'
import UI from './Modules/UI'